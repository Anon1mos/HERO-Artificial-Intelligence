# HERO

Assistente pessoal com chat, briefing, tarefas, histórico, voz, controle por mãos, login e relatório mensal.

## Como usar (esta pasta já vem completa)
Ela inclui o código, a `.venv` com tudo instalado, o seu `.env`, o `hero.db` e o `settings.json` que você já usava.
1. Abra **`iniciar.py`** no VS Code e clique no botão de executar (triângulo), ou no terminal da pasta rode:
   `.venv\Scripts\python.exe iniciar.py`. Ele abre o navegador em http://localhost:8900 (Ctrl+C para parar).
   Se o Windows deixar, o `iniciar.bat` faz o mesmo com dois cliques. Em computadores com política de segurança (Device Guard),
   `.bat` e `.exe` podem ser bloqueados; o `.py` roda pelo `python.exe`, que costuma ser liberado.
   Alternativa: `.venv\Scripts\python.exe -m uvicorn server:app --host 127.0.0.1 --port 8900`
2. No primeiro acesso, crie a conta do **administrador**: ela herda as conversas, tarefas e configurações que já existiam.
3. O banco é atualizado sozinho. A pasta `backup-antes-do-login` guarda uma cópia do `hero.db` e do `settings.json` originais.

**Pasta sincronizada (OneDrive, Área de Trabalho):** evite deixar o `hero.db` numa pasta sincronizada; o SQLite pode dar erro de bloqueio ou conflito. O ideal é mover a pasta para um lugar como `C:\HERO`. Depois de mover, use sempre o `iniciar.bat` (os scripts `activate` da `.venv` guardam o caminho antigo) e `.venv\Scripts\python.exe -m pip` em vez de `pip`.

**Se um dia recriar a `.venv`:** `python -m venv .venv` e depois `.venv\Scripts\python.exe -m pip install -r requirements.txt`.

## Login
- Senhas guardadas com scrypt (nunca em texto). Sessão de 30 dias por cookie `HttpOnly` + `SameSite=Strict`.
- 5 erros de senha seguidos bloqueiam novas tentativas por 10 minutos.
- O cadastro fica **fechado** depois da primeira conta. Para permitir mais pessoas, coloque `ALLOW_SIGNUP=1` no `.env`; cada conta vê só os próprios dados. A conta de e-mail do `.env` só serve ao administrador.
- Trocar a senha: Configurações > Conta. **Esqueceu a senha?** No computador da HERO: `python reset_password.py SEU_USUARIO`.

## Relatório mensal
Página **Relatório**: mensagens, conversas, dias ativos, tarefas (criadas, concluídas, tempo médio), briefings, clima, e-mails e notícias vistos, uso de voz e de gestos, horários de pico, assuntos frequentes e comparação com o mês anterior.
- Meses fechados ficam congelados na primeira geração (botão Atualizar recalcula).
- **Baixar HTML** gera um arquivo único e independente; **Imprimir / PDF** abre a versão de impressão.
- **Gerar análise com IA** envia ao modelo só números agregados, nunca o texto das conversas.
- O relatório só tem dados a partir da versão com login; conversas antigas têm data aproximada.

## Segurança
- O servidor só aceita Host local (`localhost`, `127.0.0.1`). Para outro nome, defina `ALLOWED_HOSTS` no `.env`.
- Não exponha a HERO na internet sem um proxy com HTTPS à frente.
- RSS e iCal que apontam para a rede interna são bloqueados (`ALLOW_PRIVATE_URLS=1` libera).
- Os dados ficam em `hero.db` (sem criptografia). Faça backup desse arquivo. O `.gitignore` já protege `.env` e os dados.

## Testes
```
pip install -r requirements-dev.txt
python -m pytest tests -q
```
## Direitos autorais

**Desenvolvido por SmartAutistic** 
Criado com curiosidade, criatividade e vontade de transformar ideias em realidade.

**© 2026 SmartAutistic. Todos os direitos reservados, conforme a licença do projeto.**


## Version in English

# HERO

Personal assistant featuring chat, briefings, tasks, history, voice, hand gesture control, login, and monthly reports.

## How to Use (this folder comes fully configured)

This folder includes the source code, the `.venv` virtual environment with all dependencies installed, your `.env` file, `hero.db`, and the `settings.json` file you were already using.

1. Open **`iniciar.py`** in VS Code and click the Run button (triangle), or open a terminal in the project folder and run:

   `.venv\Scripts\python.exe iniciar.py`

   This opens the application in your browser at [http://localhost:8900](http://localhost:8900). Press `Ctrl+C` to stop it.

   If Windows allows it, `iniciar.bat` does the same thing with a double-click. On computers with security policies such as Device Guard, `.bat` and `.exe` files may be blocked, while `.py` files executed through `python.exe` are often allowed.

   Alternative command:

   `.venv\Scripts\python.exe -m uvicorn server:app --host 127.0.0.1 --port 8900`

2. On the first access, create the **administrator account**. It inherits the conversations, tasks, and settings that already existed.

3. The database is updated automatically. The `backup-antes-do-login` folder contains a copy of the original `hero.db` and `settings.json` files.

**Synchronized folders (OneDrive, Desktop):** Avoid keeping `hero.db` inside a synchronized folder. SQLite may encounter file-locking errors or conflicts. Ideally, move the project folder to a location such as `C:\HERO`. After moving it, always use `iniciar.bat` to start the application, since the `.venv` activation scripts retain the old path. Use `.venv\Scripts\python.exe -m pip` instead of `pip`.

**If you ever need to recreate the `.venv`:**

Run `python -m venv .venv`, then:

`.venv\Scripts\python.exe -m pip install -r requirements.txt`

## Login

- Passwords are stored using scrypt, never in plain text. Sessions last 30 days and use cookies with `HttpOnly` and `SameSite=Strict`.
- Five consecutive incorrect password attempts block further attempts for 10 minutes.
- Registration is **disabled** after the first account is created. To allow other people to register, set `ALLOW_SIGNUP=1` in the `.env` file. Each account can only access its own data. The email account configured in `.env` is reserved for the administrator.
- To change your password, go to Settings > Account. **Forgot your password?** On the computer running HERO, execute: `python reset_password.py YOUR_USERNAME`.

## Monthly Report

The **Report** page displays messages, conversations, active days, tasks (created, completed, and average completion time), briefings, weather, viewed emails and news, voice and gesture usage, peak activity hours, frequently discussed topics, and comparisons with the previous month.

- Closed months are frozen when the report is first generated. Clicking **Refresh** recalculates the report.
- **Download HTML** generates a standalone HTML file.
- **Print / PDF** opens the print-friendly version.
- **Generate AI Analysis** sends only aggregated numerical data to the AI model, never the text of conversations.
- Reports only contain data collected since the version with login was introduced. Older conversations have approximate dates.

## Security

- The server only accepts local hosts (`localhost`, `127.0.0.1`). To allow another hostname, configure `ALLOWED_HOSTS` in the `.env` file.
- Do not expose HERO to the internet without a reverse proxy with HTTPS in front of it.
- RSS and iCal URLs pointing to internal networks are blocked. Setting `ALLOW_PRIVATE_URLS=1` disables this protection.
- Data is stored in `hero.db` without encryption. Back up this file regularly. The `.gitignore` file already protects `.env` and data files.

## Tests

```bash
pip install -r requirements-dev.txt
python -m pytest tests -q
```

## Copyright

**Developed by SmartAutistic**

Created with curiosity, creativity, and the desire to turn ideas into reality.

**© 2026 SmartAutistic. All rights reserved, subject to the project's license.**